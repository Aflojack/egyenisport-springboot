package hu.egyenisport.enyeni_sport_spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EnyeniSportSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(EnyeniSportSpringApplication.class, args);
	}

}
