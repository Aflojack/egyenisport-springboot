package hu.egyenisport.enyeni_sport_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnyeniSportSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
